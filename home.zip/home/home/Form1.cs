﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using home.UserControls;

namespace home
{
    public partial class Form1 : Form
    {
        private int currentGameId = 1; // 1 = Liên Quân, 2 = Free Fire

        public Form1()
        {
            InitializeComponent();

            // Ensure login/register visible on top right (guard nulls)
            if (linkLogin != null) linkLogin.ForeColor = Color.White;
            if (linkRegister != null) linkRegister.ForeColor = Color.White;

            // No game toggle buttons (removed)

            // Only load tournaments if panels exist
            if (flpLienQuan != null && flpFreeFire != null && flpPopular != null)
                LoadTournaments();
        }

        private void btnLienQuan_Click(object sender, EventArgs e)
        {
            currentGameId = 1;
            LoadTournaments();
        }

        private void btnFreeFire_Click(object sender, EventArgs e)
        {
            currentGameId = 2;
            LoadTournaments();
        }
        private void LoadTournaments()
        {
            // debug: list images found
            try
            {
                string imagesDirDebug = Path.Combine(Application.StartupPath, "images");
                if (Directory.Exists(imagesDirDebug))
                {
                    var files = Directory.GetFiles(imagesDirDebug);
                    System.Diagnostics.Debug.WriteLine("images found:\n" + string.Join("\n", files));
                }
                else
                {
                    System.Diagnostics.Debug.WriteLine("images folder not found: " + imagesDirDebug);
                }
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine("Error listing images: " + ex.Message);
            }

            // Clear existing (but keep design-time LQ placeholders if present)
            // For LQ, prefer to reuse placeholders ucLQ1..ucLQ4 when available in designer
            var lqPlaceholders = new List<home.UserControls.UcTournamentCard>();
            try
            {
                if (this.ucLQ1 != null && flpLienQuan.Controls.Contains(this.ucLQ1)) lqPlaceholders.Add(this.ucLQ1);
                if (this.ucLQ2 != null && flpLienQuan.Controls.Contains(this.ucLQ2)) lqPlaceholders.Add(this.ucLQ2);
                if (this.ucLQ3 != null && flpLienQuan.Controls.Contains(this.ucLQ3)) lqPlaceholders.Add(this.ucLQ3);
                if (this.ucLQ4 != null && flpLienQuan.Controls.Contains(this.ucLQ4)) lqPlaceholders.Add(this.ucLQ4);
            }
            catch { }

            // If there are placeholders, remove other runtime controls but keep placeholders
            if (lqPlaceholders.Count > 0)
            {
                var toRemove = flpLienQuan.Controls.Cast<Control>().Where(c => !(c is home.UserControls.UcTournamentCard) || !lqPlaceholders.Contains((home.UserControls.UcTournamentCard)c)).ToList();
                foreach (var c in toRemove) flpLienQuan.Controls.Remove(c);
                // Example: if you want the first card to sit lower than the others, change its Margin
                // FlowLayoutPanel controls are auto-laid out; moving one in Designer will reflow others.
                // To offset a single card, set its Margin instead of dragging.
                if (lqPlaceholders.Count > 0 && lqPlaceholders[0] != null)
                {
                    lqPlaceholders[0].Margin = new Padding(10, 40, 10, 10); // left, top, right, bottom
                }
            }
            else
            {
                flpLienQuan.Controls.Clear();
            }

            // Clear other sections fully
            flpFreeFire.Controls.Clear();
            flpPopular.Controls.Clear();

            string imagesDir = Path.Combine(Application.StartupPath, "images");

            // Load Liên Quân images (lq*.*)
            var lqFiles = new List<string>();
            if (Directory.Exists(imagesDir))
            {
                // Prefer files that explicitly indicate LQ, but fall back to any image (including unamed.png)
                var allFiles = Directory.GetFiles(imagesDir);
                var imageFiles = allFiles.Where(f => {
                    var ext = Path.GetExtension(f).ToLower();
                    return ext == ".png" || ext == ".jpg" || ext == ".jpeg" || ext == ".bmp" || ext == ".gif";
                }).ToList();

                lqFiles = imageFiles
                    .Where(f => {
                        var name = Path.GetFileName(f).ToLower();
                        return name.StartsWith("lq") || name.Contains("lienquan") || name.Contains("unamed");
                    })
                    .ToList();

                // if none matched the LQ pattern, take any image files (use up to 4)
                if (!lqFiles.Any())
                    lqFiles = imageFiles.Take(4).ToList();
            }

            var lqImages = new List<Image>();
            foreach (var f in lqFiles.Take(4))
            {
                var img = LoadImage(f);
                if (img != null) lqImages.Add(img);
            }

            while (lqImages.Count < 4)
                lqImages.Add(CreateSolidBitmap(Color.Magenta, 700, 400));

            for (int i = 0; i < lqImages.Count; i++)
            {
                if (i < lqPlaceholders.Count)
                {
                    // reuse placeholder
                    var ph = lqPlaceholders[i];
                    ph.SetData(lqImages[i], $"Liên Quân - Giải {i + 1}", "01/04/2026 - 30/04/2026", "Ghi chú: thông tin ngắn về giải đấu...");
                }
                else
                {
                    var card = new UcTournamentCard();
                    card.SetData(lqImages[i], $"Liên Quân - Giải {i + 1}", "01/04/2026 - 30/04/2026", "Ghi chú: thông tin ngắn về giải đấu...");
                    flpLienQuan.Controls.Add(card);
                }
            }

            // Load Free Fire images (ff*.*)
            var ffFiles = new List<string>();
            if (Directory.Exists(imagesDir))
            {
                var allFiles = Directory.GetFiles(imagesDir);
                var imageFiles = allFiles.Where(f => {
                    var ext = Path.GetExtension(f).ToLower();
                    return ext == ".png" || ext == ".jpg" || ext == ".jpeg" || ext == ".bmp" || ext == ".gif";
                }).ToList();

                ffFiles = imageFiles
                    .Where(f => {
                        var name = Path.GetFileName(f).ToLower();
                        return name.StartsWith("ff") || name.Contains("freefire") || name.Contains("unamed");
                    })
                    .ToList();

                if (!ffFiles.Any())
                    ffFiles = imageFiles.Skip(lqFiles.Count).Take(4).ToList();
            }

            var ffImages = new List<Image>();
            foreach (var f in ffFiles.Take(4))
            {
                var img = LoadImage(f);
                if (img != null) ffImages.Add(img);
            }
            while (ffImages.Count < 4)
                ffImages.Add(CreateSolidBitmap(Color.OrangeRed, 700, 400));

            for (int i = 0; i < ffImages.Count; i++)
            {
                // reuse FF placeholders if present
                try
                {
                    if (i == 0 && this.ucFF1 != null && flpFreeFire.Controls.Contains(this.ucFF1))
                    {
                        this.ucFF1.SetData(ffImages[i], $"Free Fire - Giải {i + 1}", "05/04/2026 - 20/04/2026", "Ghi chú: ...");
                        continue;
                    }
                    if (i == 1 && this.ucFF2 != null && flpFreeFire.Controls.Contains(this.ucFF2))
                    {
                        this.ucFF2.SetData(ffImages[i], $"Free Fire - Giải {i + 1}", "05/04/2026 - 20/04/2026", "Ghi chú: ...");
                        continue;
                    }
                    if (i == 2 && this.ucFF3 != null && flpFreeFire.Controls.Contains(this.ucFF3))
                    {
                        this.ucFF3.SetData(ffImages[i], $"Free Fire - Giải {i + 1}", "05/04/2026 - 20/04/2026", "Ghi chú: ...");
                        continue;
                    }
                    if (i == 3 && this.ucFF4 != null && flpFreeFire.Controls.Contains(this.ucFF4))
                    {
                        this.ucFF4.SetData(ffImages[i], $"Free Fire - Giải {i + 1}", "05/04/2026 - 20/04/2026", "Ghi chú: ...");
                        continue;
                    }
                }
                catch { }

                var card = new UcTournamentCard();
                card.SetData(ffImages[i], $"Free Fire - Giải {i + 1}", "05/04/2026 - 20/04/2026", "Ghi chú: thông tin ngắn về giải đấu...");
                flpFreeFire.Controls.Add(card);
            }

            // If a specific featured image exists (lienquan1.jpg) add it first to LQ
            var featuredPath = Path.Combine(imagesDir, "lienquan1.jpg");
            if (File.Exists(featuredPath))
            {
                var img = LoadImage(featuredPath);
                if (img != null)
                {
                    var featured = new UcTournamentCard();
                    featured.SetData(img, "AOV Đấu Trường Danh Vọng", "01/04/2026 - 30/04/2026", "Giải chuyên nghiệp");
                    flpLienQuan.Controls.Add(featured);
                    flpLienQuan.Controls.SetChildIndex(featured, 0);
                }
            }
        }

        private Image CreateSolidBitmap(Color c, int w, int h)
        {
            Bitmap bmp = new Bitmap(w, h);
            using (Graphics g = Graphics.FromImage(bmp))
            {
                g.Clear(c);
                // Draw simple white circle to simulate a badge
                Brush brush = Brushes.White;
                g.FillEllipse(brush, w / 4, h / 4, w / 2, h / 2);
            }
            return bmp;
        }

        private void lblPopularHeader_Click(object sender, EventArgs e)
        {

        }
        private Image LoadImage(string path)
        {
            if (!File.Exists(path)) return null; // Nếu không tìm thấy ảnh thì bỏ qua để không bị crash app

            using (var fs = new FileStream(path, FileMode.Open, FileAccess.Read))
            {
                return new Bitmap(Image.FromStream(fs));
            }
        }

        private void ucLQ1_Load(object sender, EventArgs e)
        {

        }
    }
}
