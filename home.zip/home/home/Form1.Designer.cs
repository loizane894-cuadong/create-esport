﻿namespace home
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        private System.Windows.Forms.Panel pnlTopBar;
        private System.Windows.Forms.LinkLabel linkLogin;
        private System.Windows.Forms.LinkLabel linkRegister;
        private System.Windows.Forms.FlowLayoutPanel flpTopBarRight;

        private System.Windows.Forms.Panel pnlNavBar;
        private System.Windows.Forms.PictureBox pictureBoxLogo;
        private System.Windows.Forms.Button btnHome;
        private System.Windows.Forms.Button btnOngoing;
        private System.Windows.Forms.Button btnTeams;
        private System.Windows.Forms.Button btnMatches;

        private System.Windows.Forms.Panel pnlGameToggle;
        private System.Windows.Forms.Panel pnlHero;
        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.TextBox txtSearch;
        private System.Windows.Forms.Button btnSearch;

        private System.Windows.Forms.Panel pnlMainContent;
        private System.Windows.Forms.Label lblFeaturedHeader;
        private System.Windows.Forms.Label lblLienQuanHeader;
        private System.Windows.Forms.FlowLayoutPanel flpLienQuan;
        private home.UserControls.UcTournamentCard ucLQ1;
        private home.UserControls.UcTournamentCard ucLQ2;
        private home.UserControls.UcTournamentCard ucLQ3;
        private home.UserControls.UcTournamentCard ucLQ4;
        private home.UserControls.UcTournamentCard ucFF1;
        private home.UserControls.UcTournamentCard ucFF2;
        private home.UserControls.UcTournamentCard ucFF3;
        private home.UserControls.UcTournamentCard ucFF4;
        private System.Windows.Forms.Label lblFreeFireHeader;
        private System.Windows.Forms.FlowLayoutPanel flpFreeFire;
        private System.Windows.Forms.Label lblPopularHeader;
        private System.Windows.Forms.FlowLayoutPanel flpPopular;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnlTopBar = new System.Windows.Forms.Panel();
            this.flpTopBarRight = new System.Windows.Forms.FlowLayoutPanel();
            this.linkRegister = new System.Windows.Forms.LinkLabel();
            this.linkLogin = new System.Windows.Forms.LinkLabel();
            this.pnlNavBar = new System.Windows.Forms.Panel();
            this.btnMatches = new System.Windows.Forms.Button();
            this.btnTeams = new System.Windows.Forms.Button();
            this.btnOngoing = new System.Windows.Forms.Button();
            this.btnHome = new System.Windows.Forms.Button();
            this.pictureBoxLogo = new System.Windows.Forms.PictureBox();
            this.pnlGameToggle = new System.Windows.Forms.Panel();
            this.pnlHero = new System.Windows.Forms.Panel();
            this.lblTitle = new System.Windows.Forms.Label();
            this.txtSearch = new System.Windows.Forms.TextBox();
            this.btnSearch = new System.Windows.Forms.Button();
            this.pnlMainContent = new System.Windows.Forms.Panel();
            this.flpFreeFire = new System.Windows.Forms.FlowLayoutPanel();
            this.lblFreeFireHeader = new System.Windows.Forms.Label();
            this.flpLienQuan = new System.Windows.Forms.FlowLayoutPanel();
            this.lblLienQuanHeader = new System.Windows.Forms.Label();
            this.lblPopularHeader = new System.Windows.Forms.Label();
            this.flpPopular = new System.Windows.Forms.FlowLayoutPanel();
            this.ucFF1 = new home.UserControls.UcTournamentCard();
            this.ucFF2 = new home.UserControls.UcTournamentCard();
            this.ucFF3 = new home.UserControls.UcTournamentCard();
            this.ucFF4 = new home.UserControls.UcTournamentCard();
            this.ucLQ1 = new home.UserControls.UcTournamentCard();
            this.ucLQ2 = new home.UserControls.UcTournamentCard();
            this.ucLQ3 = new home.UserControls.UcTournamentCard();
            this.ucLQ4 = new home.UserControls.UcTournamentCard();
            this.pnlTopBar.SuspendLayout();
            this.flpTopBarRight.SuspendLayout();
            this.pnlNavBar.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxLogo)).BeginInit();
            this.pnlHero.SuspendLayout();
            this.pnlMainContent.SuspendLayout();
            this.flpFreeFire.SuspendLayout();
            this.flpLienQuan.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlTopBar
            // 
            this.pnlTopBar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(86)))), ((int)(((byte)(179)))));
            this.pnlTopBar.Controls.Add(this.flpTopBarRight);
            this.pnlTopBar.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlTopBar.Location = new System.Drawing.Point(0, 0);
            this.pnlTopBar.Name = "pnlTopBar";
            this.pnlTopBar.Size = new System.Drawing.Size(1200, 35);
            this.pnlTopBar.TabIndex = 3;
            // 
            // flpTopBarRight
            // 
            this.flpTopBarRight.Controls.Add(this.linkRegister);
            this.flpTopBarRight.Controls.Add(this.linkLogin);
            this.flpTopBarRight.Dock = System.Windows.Forms.DockStyle.Right;
            this.flpTopBarRight.FlowDirection = System.Windows.Forms.FlowDirection.RightToLeft;
            this.flpTopBarRight.Location = new System.Drawing.Point(960, 0);
            this.flpTopBarRight.Name = "flpTopBarRight";
            this.flpTopBarRight.Padding = new System.Windows.Forms.Padding(0, 6, 10, 0);
            this.flpTopBarRight.Size = new System.Drawing.Size(240, 35);
            this.flpTopBarRight.TabIndex = 0;
            // 
            // linkRegister
            // 
            this.linkRegister.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.linkRegister.AutoSize = true;
            this.linkRegister.ForeColor = System.Drawing.Color.White;
            this.linkRegister.Location = new System.Drawing.Point(180, 6);
            this.linkRegister.Name = "linkRegister";
            this.linkRegister.Size = new System.Drawing.Size(47, 13);
            this.linkRegister.TabIndex = 0;
            this.linkRegister.TabStop = true;
            this.linkRegister.Text = "Đăng ký";
            // 
            // linkLogin
            // 
            this.linkLogin.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.linkLogin.AutoSize = true;
            this.linkLogin.ForeColor = System.Drawing.Color.White;
            this.linkLogin.Location = new System.Drawing.Point(114, 6);
            this.linkLogin.Name = "linkLogin";
            this.linkLogin.Size = new System.Drawing.Size(60, 13);
            this.linkLogin.TabIndex = 1;
            this.linkLogin.TabStop = true;
            this.linkLogin.Text = "Đăng nhập";
            // 
            // pnlNavBar
            // 
            this.pnlNavBar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.pnlNavBar.Controls.Add(this.btnMatches);
            this.pnlNavBar.Controls.Add(this.btnTeams);
            this.pnlNavBar.Controls.Add(this.btnOngoing);
            this.pnlNavBar.Controls.Add(this.btnHome);
            this.pnlNavBar.Controls.Add(this.pictureBoxLogo);
            this.pnlNavBar.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlNavBar.Location = new System.Drawing.Point(0, 35);
            this.pnlNavBar.Name = "pnlNavBar";
            this.pnlNavBar.Size = new System.Drawing.Size(1200, 60);
            this.pnlNavBar.TabIndex = 2;
            // 
            // btnMatches
            // 
            this.btnMatches.BackColor = System.Drawing.Color.Transparent;
            this.btnMatches.FlatAppearance.BorderSize = 0;
            this.btnMatches.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMatches.ForeColor = System.Drawing.Color.White;
            this.btnMatches.Location = new System.Drawing.Point(400, 15);
            this.btnMatches.Name = "btnMatches";
            this.btnMatches.Size = new System.Drawing.Size(90, 30);
            this.btnMatches.TabIndex = 0;
            this.btnMatches.Text = "Bắt đối";
            this.btnMatches.UseVisualStyleBackColor = false;
            // 
            // btnTeams
            // 
            this.btnTeams.BackColor = System.Drawing.Color.Transparent;
            this.btnTeams.FlatAppearance.BorderSize = 0;
            this.btnTeams.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTeams.ForeColor = System.Drawing.Color.White;
            this.btnTeams.Location = new System.Drawing.Point(320, 15);
            this.btnTeams.Name = "btnTeams";
            this.btnTeams.Size = new System.Drawing.Size(70, 30);
            this.btnTeams.TabIndex = 1;
            this.btnTeams.Text = "Đội";
            this.btnTeams.UseVisualStyleBackColor = false;
            // 
            // btnOngoing
            // 
            this.btnOngoing.BackColor = System.Drawing.Color.Transparent;
            this.btnOngoing.FlatAppearance.BorderSize = 0;
            this.btnOngoing.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnOngoing.ForeColor = System.Drawing.Color.White;
            this.btnOngoing.Location = new System.Drawing.Point(170, 15);
            this.btnOngoing.Name = "btnOngoing";
            this.btnOngoing.Size = new System.Drawing.Size(140, 30);
            this.btnOngoing.TabIndex = 2;
            this.btnOngoing.Text = "Giải đang diễn ra";
            this.btnOngoing.UseVisualStyleBackColor = false;
            // 
            // btnHome
            // 
            this.btnHome.BackColor = System.Drawing.Color.Transparent;
            this.btnHome.FlatAppearance.BorderSize = 0;
            this.btnHome.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnHome.ForeColor = System.Drawing.Color.White;
            this.btnHome.Location = new System.Drawing.Point(70, 15);
            this.btnHome.Name = "btnHome";
            this.btnHome.Size = new System.Drawing.Size(90, 30);
            this.btnHome.TabIndex = 3;
            this.btnHome.Text = "Trang chủ";
            this.btnHome.UseVisualStyleBackColor = false;
            // 
            // pictureBoxLogo
            // 
            this.pictureBoxLogo.Location = new System.Drawing.Point(12, 6);
            this.pictureBoxLogo.Name = "pictureBoxLogo";
            this.pictureBoxLogo.Size = new System.Drawing.Size(48, 48);
            this.pictureBoxLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxLogo.TabIndex = 4;
            this.pictureBoxLogo.TabStop = false;
            // 
            // pnlGameToggle
            // 
            this.pnlGameToggle.BackColor = System.Drawing.Color.WhiteSmoke;
            this.pnlGameToggle.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlGameToggle.Location = new System.Drawing.Point(0, 0);
            this.pnlGameToggle.Name = "pnlGameToggle";
            this.pnlGameToggle.Size = new System.Drawing.Size(1200, 60);
            this.pnlGameToggle.TabIndex = 4;
            // 
            // pnlHero
            // 
            this.pnlHero.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.pnlHero.Controls.Add(this.lblTitle);
            this.pnlHero.Controls.Add(this.txtSearch);
            this.pnlHero.Controls.Add(this.btnSearch);
            this.pnlHero.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnlHero.Location = new System.Drawing.Point(0, 95);
            this.pnlHero.Name = "pnlHero";
            this.pnlHero.Size = new System.Drawing.Size(1200, 180);
            this.pnlHero.TabIndex = 1;
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Segoe UI", 16F, System.Drawing.FontStyle.Bold);
            this.lblTitle.Location = new System.Drawing.Point(260, 30);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(516, 30);
            this.lblTitle.TabIndex = 0;
            this.lblTitle.Text = "HỆ THỐNG QUẢN LÝ GIẢI ĐẤU CHUYÊN NGHIỆP";
            // 
            // txtSearch
            // 
            this.txtSearch.Location = new System.Drawing.Point(260, 110);
            this.txtSearch.Name = "txtSearch";
            this.txtSearch.Size = new System.Drawing.Size(600, 20);
            this.txtSearch.TabIndex = 1;
            // 
            // btnSearch
            // 
            this.btnSearch.BackColor = System.Drawing.Color.Gold;
            this.btnSearch.FlatAppearance.BorderSize = 0;
            this.btnSearch.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSearch.Location = new System.Drawing.Point(870, 108);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(90, 30);
            this.btnSearch.TabIndex = 2;
            this.btnSearch.Text = "Tìm kiếm";
            this.btnSearch.UseVisualStyleBackColor = false;
            // 
            // pnlMainContent
            // 
            this.pnlMainContent.BackColor = System.Drawing.Color.White;
            this.pnlMainContent.Controls.Add(this.flpFreeFire);
            this.pnlMainContent.Controls.Add(this.lblFreeFireHeader);
            this.pnlMainContent.Controls.Add(this.flpLienQuan);
            this.pnlMainContent.Controls.Add(this.lblLienQuanHeader);
            this.pnlMainContent.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlMainContent.Location = new System.Drawing.Point(0, 275);
            this.pnlMainContent.Name = "pnlMainContent";
            this.pnlMainContent.Size = new System.Drawing.Size(1200, 525);
            this.pnlMainContent.TabIndex = 0;
            // 
            // flpFreeFire
            // 
            this.flpFreeFire.AutoScroll = true;
            this.flpFreeFire.Controls.Add(this.ucFF1);
            this.flpFreeFire.Controls.Add(this.ucFF2);
            this.flpFreeFire.Controls.Add(this.ucFF3);
            this.flpFreeFire.Controls.Add(this.ucFF4);
            this.flpFreeFire.Dock = System.Windows.Forms.DockStyle.Top;
            this.flpFreeFire.Location = new System.Drawing.Point(0, 276);
            this.flpFreeFire.Name = "flpFreeFire";
            this.flpFreeFire.Padding = new System.Windows.Forms.Padding(20, 10, 20, 10);
            this.flpFreeFire.Size = new System.Drawing.Size(1200, 200);
            this.flpFreeFire.TabIndex = 4;
            this.flpFreeFire.WrapContents = false;
            // 
            // lblFreeFireHeader
            // 
            this.lblFreeFireHeader.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblFreeFireHeader.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.lblFreeFireHeader.Location = new System.Drawing.Point(0, 248);
            this.lblFreeFireHeader.Name = "lblFreeFireHeader";
            this.lblFreeFireHeader.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.lblFreeFireHeader.Size = new System.Drawing.Size(1200, 28);
            this.lblFreeFireHeader.TabIndex = 3;
            this.lblFreeFireHeader.Text = "FREE FIRE";
            this.lblFreeFireHeader.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // flpLienQuan
            // 
            this.flpLienQuan.AutoScroll = true;
            this.flpLienQuan.Controls.Add(this.ucLQ1);
            this.flpLienQuan.Controls.Add(this.ucLQ2);
            this.flpLienQuan.Controls.Add(this.ucLQ3);
            this.flpLienQuan.Controls.Add(this.ucLQ4);
            this.flpLienQuan.Dock = System.Windows.Forms.DockStyle.Top;
            this.flpLienQuan.Location = new System.Drawing.Point(0, 28);
            this.flpLienQuan.Name = "flpLienQuan";
            this.flpLienQuan.Padding = new System.Windows.Forms.Padding(20, 10, 20, 10);
            this.flpLienQuan.Size = new System.Drawing.Size(1200, 220);
            this.flpLienQuan.TabIndex = 2;
            this.flpLienQuan.WrapContents = false;
            // 
            // lblLienQuanHeader
            // 
            this.lblLienQuanHeader.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblLienQuanHeader.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.lblLienQuanHeader.Location = new System.Drawing.Point(0, 0);
            this.lblLienQuanHeader.Name = "lblLienQuanHeader";
            this.lblLienQuanHeader.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.lblLienQuanHeader.Size = new System.Drawing.Size(1200, 28);
            this.lblLienQuanHeader.TabIndex = 1;
            this.lblLienQuanHeader.Text = "LIÊN QUÂN";
            this.lblLienQuanHeader.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblPopularHeader
            // 
            this.lblPopularHeader.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblPopularHeader.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.lblPopularHeader.Location = new System.Drawing.Point(0, 526);
            this.lblPopularHeader.Name = "lblPopularHeader";
            this.lblPopularHeader.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.lblPopularHeader.Size = new System.Drawing.Size(1200, 28);
            this.lblPopularHeader.TabIndex = 5;
            this.lblPopularHeader.Text = "GIẢI NHIỀU NGƯỜI XEM";
            this.lblPopularHeader.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // flpPopular
            // 
            this.flpPopular.AutoScroll = true;
            this.flpPopular.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flpPopular.Location = new System.Drawing.Point(0, 554);
            this.flpPopular.Name = "flpPopular";
            this.flpPopular.Padding = new System.Windows.Forms.Padding(20, 10, 20, 10);
            this.flpPopular.Size = new System.Drawing.Size(1200, 0);
            this.flpPopular.TabIndex = 6;
            // 
            // ucFF1
            // 
            this.ucFF1.BackColor = System.Drawing.Color.White;
            this.ucFF1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.ucFF1.Location = new System.Drawing.Point(30, 20);
            this.ucFF1.Margin = new System.Windows.Forms.Padding(10);
            this.ucFF1.Name = "ucFF1";
            this.ucFF1.Size = new System.Drawing.Size(250, 200);
            this.ucFF1.TabIndex = 4;
            // 
            // ucFF2
            // 
            this.ucFF2.BackColor = System.Drawing.Color.White;
            this.ucFF2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.ucFF2.Location = new System.Drawing.Point(300, 20);
            this.ucFF2.Margin = new System.Windows.Forms.Padding(10);
            this.ucFF2.Name = "ucFF2";
            this.ucFF2.Size = new System.Drawing.Size(250, 200);
            this.ucFF2.TabIndex = 5;
            // 
            // ucFF3
            // 
            this.ucFF3.BackColor = System.Drawing.Color.White;
            this.ucFF3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.ucFF3.Location = new System.Drawing.Point(570, 20);
            this.ucFF3.Margin = new System.Windows.Forms.Padding(10);
            this.ucFF3.Name = "ucFF3";
            this.ucFF3.Size = new System.Drawing.Size(250, 200);
            this.ucFF3.TabIndex = 6;
            // 
            // ucFF4
            // 
            this.ucFF4.BackColor = System.Drawing.Color.White;
            this.ucFF4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.ucFF4.Location = new System.Drawing.Point(840, 20);
            this.ucFF4.Margin = new System.Windows.Forms.Padding(10);
            this.ucFF4.Name = "ucFF4";
            this.ucFF4.Size = new System.Drawing.Size(250, 200);
            this.ucFF4.TabIndex = 7;
            // 
            // ucLQ1
            // 
            this.ucLQ1.BackColor = System.Drawing.Color.White;
            this.ucLQ1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.ucLQ1.Location = new System.Drawing.Point(30, 20);
            this.ucLQ1.Margin = new System.Windows.Forms.Padding(10);
            this.ucLQ1.Name = "ucLQ1";
            this.ucLQ1.Size = new System.Drawing.Size(250, 428);
            this.ucLQ1.TabIndex = 0;
            this.ucLQ1.Load += new System.EventHandler(this.ucLQ1_Load);
            // 
            // ucLQ2
            // 
            this.ucLQ2.BackColor = System.Drawing.Color.White;
            this.ucLQ2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.ucLQ2.Location = new System.Drawing.Point(300, 20);
            this.ucLQ2.Margin = new System.Windows.Forms.Padding(10);
            this.ucLQ2.Name = "ucLQ2";
            this.ucLQ2.Size = new System.Drawing.Size(250, 428);
            this.ucLQ2.TabIndex = 1;
            // 
            // ucLQ3
            // 
            this.ucLQ3.BackColor = System.Drawing.Color.White;
            this.ucLQ3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.ucLQ3.Location = new System.Drawing.Point(570, 20);
            this.ucLQ3.Margin = new System.Windows.Forms.Padding(10);
            this.ucLQ3.Name = "ucLQ3";
            this.ucLQ3.Size = new System.Drawing.Size(250, 428);
            this.ucLQ3.TabIndex = 2;
            // 
            // ucLQ4
            // 
            this.ucLQ4.BackColor = System.Drawing.Color.White;
            this.ucLQ4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.ucLQ4.Location = new System.Drawing.Point(840, 20);
            this.ucLQ4.Margin = new System.Windows.Forms.Padding(10);
            this.ucLQ4.Name = "ucLQ4";
            this.ucLQ4.Size = new System.Drawing.Size(250, 428);
            this.ucLQ4.TabIndex = 3;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1200, 800);
            this.Controls.Add(this.pnlMainContent);
            this.Controls.Add(this.pnlHero);
            this.Controls.Add(this.pnlNavBar);
            this.Controls.Add(this.pnlTopBar);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FrmMain";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.pnlTopBar.ResumeLayout(false);
            this.flpTopBarRight.ResumeLayout(false);
            this.flpTopBarRight.PerformLayout();
            this.pnlNavBar.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxLogo)).EndInit();
            this.pnlHero.ResumeLayout(false);
            this.pnlHero.PerformLayout();
            this.pnlMainContent.ResumeLayout(false);
            this.flpFreeFire.ResumeLayout(false);
            this.flpLienQuan.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
    }
}

